export default {

    // Puzzle Categories
    categories : [
        "Art",
        "Apple",
        "Animal",
        "Car",
        "City",
        "Gradient",
        "Street",
        "Wonder",
    ],

    // Puzzles por Categories
    puzzles : 10,

    // Pieces por Puzzle
    pieces : [ "50", "100", "250", "500" ],

};
